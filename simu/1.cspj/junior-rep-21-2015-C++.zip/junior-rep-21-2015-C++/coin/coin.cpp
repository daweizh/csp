#include <iostream>
using namespace std;

int main(){
	int d,i,m=0;
	
	cin >> d;
	for(i=1;i<d;i++){
		m = m + i*i;
		d = d - i;
	}
	m = m + i * d;
	
	cout << m << endl;
	
	return 0;
}
